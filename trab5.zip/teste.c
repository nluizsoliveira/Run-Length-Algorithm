#include<stdio.h>

int main (){
    int teste;
    scanf("%d",  &teste);

    printf("arroba tem = %d", teste);
}